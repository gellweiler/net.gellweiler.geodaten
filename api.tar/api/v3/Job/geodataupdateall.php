<?php
/**
 * Update geodata for all address records.
 */
function civicrm_api3_job_geodataupdateall($params) {
  geodaten_update_all();
}
